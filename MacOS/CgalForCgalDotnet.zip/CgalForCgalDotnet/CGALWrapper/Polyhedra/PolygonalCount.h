#pragma once


struct PolygonalCount
{
	int degenerate;
	int three;
	int four;
	int five;
	int six;
	int greater;
};

