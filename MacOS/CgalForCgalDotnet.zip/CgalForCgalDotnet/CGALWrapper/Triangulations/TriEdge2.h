#pragma once

#include "../CGALWrapper.h"
#include "../Geometry/Geometry2.h"

#include "CGAL/Point_2.h"

struct TriEdge2
{
	int FaceIndex;
	int NeighbourIndex;
};
