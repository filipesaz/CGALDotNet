#pragma once

struct MinMax
{
	double min;
	double max;
};

struct MinMaxAvg
{
	double min;
	double max;
	double avg;
};
