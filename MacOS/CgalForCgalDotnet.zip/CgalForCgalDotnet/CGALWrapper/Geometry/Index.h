#pragma once

struct Index2
{
	int first;
	int second;
};

struct Index3
{
	int first;
	int second;
	int third;
};

struct Index4
{
	int first;
	int second;
	int third;
	int fourth;
};
